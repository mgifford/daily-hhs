FOR IMMEDIATE RELEASE

# HHS Website Accessibility Report: August 31, 2026

*Washington, D.C. -- August 31, 2026* -- A daily scan of 70 of the most-visited HHS government websites found 144 accessibility barriers across 70 URLs today. The most common issues include Digital Motor Access, Primary Content Identification, and Visual Information Access.

These barriers prevent Americans with disabilities from independently accessing essential HHS government services. This is a single daily snapshot of the most popular ~70 pages in HHS web properties, as ranked by traffic data from [analytics.usa.gov](https://analytics.usa.gov/health-human-services) (powered by the Digital Analytics Program, DAP).

## Americans Being Left Out

Based on page traffic data and U.S. Census disability prevalence estimates (ACS 2022), today's accessibility barriers are estimated to affect the following groups of Americans:

| Disability Group | Affected Page Loads | Estimated People Affected |
|-----------------|---------------------|--------------------------|
| Limited Reach and Strength | 1,803,789 | ~104,620 |
| Without Perception of Color | 2,235,687 | ~96,135 |
| Limited Manipulation | 2,688,168 | ~59,140 |
| Limited Vision | 2,240,492 | ~53,772 |
| Without Vision | 2,035,771 | ~20,358 |
| Without Hearing | 2,035,771 | ~6,107 |
| Limited Language, Cognitive, and Learning Abilities | 2,425 | ~114 |

*Total page loads across all scanned URLs today: 11,380,475*

*Estimates use disability prevalence rates from the U.S. Census Bureau American Community Survey (ACS) 2022, supplemented by CDC, NIDCD, AFB, and NIH/NEI data. These are rough estimates intended to illustrate the scale of accessibility barriers, not precise measurements.*

## Top Accessibility Barriers

The following accessibility issues were most frequently found across today's scanned government websites. Each issue prevents specific groups of Americans from independently accessing government services.

### 1. `target-size`: Digital Motor Access

*Found on 24 government websites today*

Small touch targets act as a digital gatekeeper, excluding individuals with tremors, arthritis, or limited dexterity from accessing essential services independently. These technical failures transform a routine interaction into a source of failure, stripping away the autonomy of citizens who require a frictionless, accessible interface to participate in digital life. The approximately 58 million Americans with ambulatory or self-care disabilities are disproportionately impacted by inadequate touch target sizing on government mobile websites.

**Affected groups:**

- People with Parkinson's disease, arthritis, or hand tremors
- Older adults with reduced fine motor control
- People with motor disabilities using alternative pointing devices
- People in situational impairment contexts (e.g., commuting, holding a child)

### 2. `landmark-one-main`: Primary Content Identification

*Found on 22 government websites today*

Without a main landmark, screen reader users lose their most efficient way to skip to the primary content of a government page. Every page visit requires tabbing through the entire navigation structure to reach the actual content, a significant time and effort burden that accumulates across repeated visits to government websites for citizens managing ongoing benefit cases or legal matters.

**Affected groups:**

- People who are blind using screen readers
- People who are deaf and rely on visual-to-text tools
- People with motor disabilities using keyboard navigation

### 3. `color-contrast`: Visual Information Access

*Found on 20 government websites today*

Low contrast text is one of the most pervasive barriers on government websites, rendering critical information invisible to the approximately 26 million Americans with low vision or color blindness. When agency announcements, form instructions, error messages, or legal notices are displayed in insufficient contrast, affected citizens are denied equal access to the information they need to exercise their rights and access public services.

**Affected groups:**

- People with low vision including age-related vision loss
- People who are color blind (approximately 8% of men, 0.5% of women)

### 4. `heading-order`: Document Structure Navigation

*Found on 16 government websites today*

Screen reader users navigate complex government websites primarily through heading structure, using headings as a table of contents to jump between sections. Skipped heading levels break the logical document outline, causing confusion about the hierarchy of information and forcing users to re-read sections to understand the relationship between topics, adding significant time and effort to information-gathering tasks.

**Affected groups:**

- People who are blind using screen readers
- People who are deaf and rely on visual-to-text tools
- People with motor disabilities using keyboard navigation

### 5. `link-in-text-block`: Color-Independent Link Identification

*Found on 11 government websites today*

When links are distinguished only by color, people with color vision deficiency cannot identify them as links and may miss critical references to additional information, forms, or resources. On government websites, overlooked links in informational content can mean missing essential instructions, deadlines, or procedures that affect a citizen's ability to access services or comply with requirements.

**Affected groups:**

- People with low vision who may not perceive color differences
- People who are color blind (approximately 8% of men, 0.5% of women)

## Accessibility Scores

Aggregate Lighthouse scores across 70 scanned HHS government websites today:

| Metric | Score |
|--------|-------|
| Accessibility | 91.9 |
| Performance | 52.65 |
| Best Practices | 91.52 |
| SEO | 86.49 |

## About This Report

This report captures a daily snapshot of the most-visited HHS government web pages as ranked by traffic data from [analytics.usa.gov](https://analytics.usa.gov/health-human-services), powered by the Digital Analytics Program (DAP). Scans use Lighthouse (Google's automated web quality tool, which includes axe-core for accessibility testing). Reports are published automatically each day.

- [View full interactive report](https://mgifford.github.io/daily-hhs/docs/reports/daily/2026-08-31/index.html)
- [Download accessibility findings (JSON)](https://mgifford.github.io/daily-hhs/docs/reports/daily/2026-08-31/axe-findings.json)
- [Download accessibility findings (CSV)](https://mgifford.github.io/daily-hhs/docs/reports/daily/2026-08-31/axe-findings.csv)

---

*Generated by [Daily HHS](https://github.com/mgifford/daily-hhs) | Source: [analytics.usa.gov/health-human-services](https://analytics.usa.gov/health-human-services) (Digital Analytics Program) | Methodology: Lighthouse + axe-core | Date: 2026-08-31*
